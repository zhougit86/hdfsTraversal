package models

type SkewedStringList struct {
	StringListId int64 `xorm:"not null pk BIGINT(20)"`
}
