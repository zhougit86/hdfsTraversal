package models

type TestInitialization struct {
	Name string `xorm:"CHAR(10)"`
}
